# Habit Tracker — Android Studio (Java)

A clean, fully-featured habit tracking Android app built with Java and SQLite.

---

## Features

- ✅ **Add / Edit / Delete habits** with name, description, frequency, color, and icon
- 🔥 **Streak tracking** — automatically calculated daily
- 📋 **Daily checklist** — check off habits each day from the home screen
- 📈 **Statistics screen** — total completions, best streak, leaderboard
- 🗓 **Completion history** — see every time a habit was logged
- 💾 **Local SQLite database** — no internet required

---

## Project Structure

```
app/src/main/
├── java/com/habittracker/
│   ├── activities/
│   │   ├── MainActivity.java          ← Home: daily checklist
│   │   ├── AddEditHabitActivity.java  ← Create & edit habits
│   │   ├── HabitDetailActivity.java   ← Habit history & stats
│   │   └── StatsActivity.java         ← Overall stats
│   ├── adapters/
│   │   ├── HabitAdapter.java          ← RecyclerView for home list
│   │   ├── LogAdapter.java            ← Completion history list
│   │   └── HabitStatsAdapter.java     ← Stats leaderboard
│   ├── database/
│   │   └── DatabaseHelper.java        ← SQLite helper (singleton)
│   └── models/
│       ├── Habit.java
│       └── HabitLog.java
└── res/
    ├── layout/
    │   ├── activity_main.xml
    │   ├── activity_add_edit_habit.xml
    │   ├── activity_habit_detail.xml
    │   ├── activity_stats.xml
    │   ├── item_habit.xml
    │   ├── item_log.xml
    │   └── item_habit_stats.xml
    ├── drawable/
    │   ├── badge_background.xml
    │   └── spinner_background.xml
    ├── menu/
    │   └── menu_main.xml
    └── values/
        ├── colors.xml
        ├── strings.xml
        └── themes.xml
```

---

## Setup in Android Studio

1. **Open Android Studio** → File → Open → select the `HabitTracker` folder
2. Wait for Gradle sync to complete
3. Run on emulator or physical device (API 21+)

## Dependencies (auto-resolved via Gradle)

| Library | Version |
|---|---|
| AppCompat | 1.6.1 |
| Material Components | 1.11.0 |
| RecyclerView | 1.3.2 |
| CardView | 1.0.0 |
| ConstraintLayout | 2.1.4 |
| CoordinatorLayout | 1.2.0 |

---

## Database Schema

**habits**
| Column | Type | Notes |
|---|---|---|
| id | INTEGER PK | Auto-increment |
| name | TEXT | Habit name |
| description | TEXT | Optional |
| frequency | TEXT | "daily" or "weekly" |
| color | TEXT | Hex color string |
| icon | TEXT | Icon key |
| streak | INTEGER | Auto-calculated |
| created_at | INTEGER | Unix millis |

**habit_logs**
| Column | Type | Notes |
|---|---|---|
| id | INTEGER PK | Auto-increment |
| habit_id | INTEGER FK | References habits |
| completed_at | INTEGER | Unix millis |
| note | TEXT | Optional note |
