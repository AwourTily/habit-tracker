package com.habittracker.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.habittracker.models.Habit;
import com.habittracker.models.HabitLog;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "HabitTracker.db";
    private static final int DATABASE_VERSION = 1;

    // Habits table
    public static final String TABLE_HABITS = "habits";
    public static final String COL_HABIT_ID = "id";
    public static final String COL_HABIT_NAME = "name";
    public static final String COL_HABIT_DESC = "description";
    public static final String COL_HABIT_FREQUENCY = "frequency";
    public static final String COL_HABIT_COLOR = "color";
    public static final String COL_HABIT_ICON = "icon";
    public static final String COL_HABIT_STREAK = "streak";
    public static final String COL_HABIT_CREATED_AT = "created_at";

    // Logs table
    public static final String TABLE_LOGS = "habit_logs";
    public static final String COL_LOG_ID = "id";
    public static final String COL_LOG_HABIT_ID = "habit_id";
    public static final String COL_LOG_COMPLETED_AT = "completed_at";
    public static final String COL_LOG_NOTE = "note";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_HABITS_TABLE = "CREATE TABLE " + TABLE_HABITS + " ("
                + COL_HABIT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_HABIT_NAME + " TEXT NOT NULL, "
                + COL_HABIT_DESC + " TEXT, "
                + COL_HABIT_FREQUENCY + " TEXT DEFAULT 'daily', "
                + COL_HABIT_COLOR + " TEXT DEFAULT '#4CAF50', "
                + COL_HABIT_ICON + " TEXT DEFAULT 'star', "
                + COL_HABIT_STREAK + " INTEGER DEFAULT 0, "
                + COL_HABIT_CREATED_AT + " INTEGER"
                + ")";

        String CREATE_LOGS_TABLE = "CREATE TABLE " + TABLE_LOGS + " ("
                + COL_LOG_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_LOG_HABIT_ID + " INTEGER, "
                + COL_LOG_COMPLETED_AT + " INTEGER, "
                + COL_LOG_NOTE + " TEXT, "
                + "FOREIGN KEY(" + COL_LOG_HABIT_ID + ") REFERENCES " + TABLE_HABITS + "(" + COL_HABIT_ID + ")"
                + ")";

        db.execSQL(CREATE_HABITS_TABLE);
        db.execSQL(CREATE_LOGS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HABITS);
        onCreate(db);
    }

    // ─── HABIT CRUD ─────────────────────────────────────────────────────────────

    public long insertHabit(Habit habit) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_HABIT_NAME, habit.getName());
        values.put(COL_HABIT_DESC, habit.getDescription());
        values.put(COL_HABIT_FREQUENCY, habit.getFrequency());
        values.put(COL_HABIT_COLOR, habit.getColor());
        values.put(COL_HABIT_ICON, habit.getIcon());
        values.put(COL_HABIT_STREAK, 0);
        values.put(COL_HABIT_CREATED_AT, System.currentTimeMillis());
        return db.insert(TABLE_HABITS, null, values);
    }

    public List<Habit> getAllHabits() {
        List<Habit> habits = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_HABITS, null, null, null, null, null,
                COL_HABIT_NAME + " ASC");
        if (cursor.moveToFirst()) {
            do {
                Habit habit = cursorToHabit(cursor);
                habit.setCompletedToday(isCompletedToday(habit.getId()));
                habits.add(habit);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return habits;
    }

    public Habit getHabitById(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_HABITS, null,
                COL_HABIT_ID + "=?", new String[]{String.valueOf(id)},
                null, null, null);
        Habit habit = null;
        if (cursor.moveToFirst()) {
            habit = cursorToHabit(cursor);
            habit.setCompletedToday(isCompletedToday(id));
        }
        cursor.close();
        return habit;
    }

    public int updateHabit(Habit habit) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_HABIT_NAME, habit.getName());
        values.put(COL_HABIT_DESC, habit.getDescription());
        values.put(COL_HABIT_FREQUENCY, habit.getFrequency());
        values.put(COL_HABIT_COLOR, habit.getColor());
        values.put(COL_HABIT_ICON, habit.getIcon());
        values.put(COL_HABIT_STREAK, habit.getStreak());
        return db.update(TABLE_HABITS, values,
                COL_HABIT_ID + "=?", new String[]{String.valueOf(habit.getId())});
    }

    public void deleteHabit(int habitId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_LOGS, COL_LOG_HABIT_ID + "=?", new String[]{String.valueOf(habitId)});
        db.delete(TABLE_HABITS, COL_HABIT_ID + "=?", new String[]{String.valueOf(habitId)});
    }

    // ─── LOG CRUD ────────────────────────────────────────────────────────────────

    public long logCompletion(int habitId, String note) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_LOG_HABIT_ID, habitId);
        values.put(COL_LOG_COMPLETED_AT, System.currentTimeMillis());
        values.put(COL_LOG_NOTE, note);
        long result = db.insert(TABLE_LOGS, null, values);
        if (result != -1) {
            recalculateStreak(habitId);
        }
        return result;
    }

    public void removeCompletion(int habitId) {
        SQLiteDatabase db = getWritableDatabase();
        String todayStart = String.valueOf(getTodayStartMillis());
        db.delete(TABLE_LOGS,
                COL_LOG_HABIT_ID + "=? AND " + COL_LOG_COMPLETED_AT + ">=?",
                new String[]{String.valueOf(habitId), todayStart});
        recalculateStreak(habitId);
    }

    public boolean isCompletedToday(int habitId) {
        SQLiteDatabase db = getReadableDatabase();
        long startOfDay = getTodayStartMillis();
        Cursor cursor = db.query(TABLE_LOGS, new String[]{COL_LOG_ID},
                COL_LOG_HABIT_ID + "=? AND " + COL_LOG_COMPLETED_AT + ">=?",
                new String[]{String.valueOf(habitId), String.valueOf(startOfDay)},
                null, null, null);
        boolean completed = cursor.getCount() > 0;
        cursor.close();
        return completed;
    }

    public List<HabitLog> getLogsForHabit(int habitId) {
        List<HabitLog> logs = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_LOGS, null,
                COL_LOG_HABIT_ID + "=?", new String[]{String.valueOf(habitId)},
                null, null, COL_LOG_COMPLETED_AT + " DESC");
        if (cursor.moveToFirst()) {
            do {
                HabitLog log = new HabitLog();
                log.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_LOG_ID)));
                log.setHabitId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_LOG_HABIT_ID)));
                log.setCompletedAt(cursor.getLong(cursor.getColumnIndexOrThrow(COL_LOG_COMPLETED_AT)));
                log.setNote(cursor.getString(cursor.getColumnIndexOrThrow(COL_LOG_NOTE)));
                logs.add(log);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return logs;
    }

    public int getTotalCompletions(int habitId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_LOGS + " WHERE " + COL_LOG_HABIT_ID + "=?",
                new String[]{String.valueOf(habitId)});
        int count = 0;
        if (cursor.moveToFirst()) count = cursor.getInt(0);
        cursor.close();
        return count;
    }

    // ─── HELPERS ─────────────────────────────────────────────────────────────────

    private Habit cursorToHabit(Cursor cursor) {
        Habit habit = new Habit();
        habit.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_HABIT_ID)));
        habit.setName(cursor.getString(cursor.getColumnIndexOrThrow(COL_HABIT_NAME)));
        habit.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COL_HABIT_DESC)));
        habit.setFrequency(cursor.getString(cursor.getColumnIndexOrThrow(COL_HABIT_FREQUENCY)));
        habit.setColor(cursor.getString(cursor.getColumnIndexOrThrow(COL_HABIT_COLOR)));
        habit.setIcon(cursor.getString(cursor.getColumnIndexOrThrow(COL_HABIT_ICON)));
        habit.setStreak(cursor.getInt(cursor.getColumnIndexOrThrow(COL_HABIT_STREAK)));
        habit.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow(COL_HABIT_CREATED_AT)));
        return habit;
    }

    private long getTodayStartMillis() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    private void recalculateStreak(int habitId) {
        SQLiteDatabase db = getWritableDatabase();
        // Get all distinct completion dates ordered descending
        Cursor cursor = db.rawQuery(
                "SELECT date(" + COL_LOG_COMPLETED_AT + "/1000, 'unixepoch', 'localtime') as day " +
                        "FROM " + TABLE_LOGS + " WHERE " + COL_LOG_HABIT_ID + "=? " +
                        "GROUP BY day ORDER BY day DESC",
                new String[]{String.valueOf(habitId)});

        int streak = 0;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String expectedDay = sdf.format(new Date());

        if (cursor.moveToFirst()) {
            do {
                String day = cursor.getString(0);
                if (day.equals(expectedDay)) {
                    streak++;
                    // move expected back one day
                    java.util.Calendar cal = java.util.Calendar.getInstance();
                    try {
                        cal.setTime(sdf.parse(expectedDay));
                        cal.add(java.util.Calendar.DAY_OF_YEAR, -1);
                        expectedDay = sdf.format(cal.getTime());
                    } catch (Exception e) {
                        break;
                    }
                } else {
                    break;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();

        ContentValues values = new ContentValues();
        values.put(COL_HABIT_STREAK, streak);
        db.update(TABLE_HABITS, values, COL_HABIT_ID + "=?", new String[]{String.valueOf(habitId)});
    }
}
