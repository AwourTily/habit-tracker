package com.habittracker.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.habittracker.R;
import com.habittracker.adapters.HabitStatsAdapter;
import com.habittracker.database.DatabaseHelper;
import com.habittracker.models.Habit;

import java.util.Comparator;
import java.util.List;

public class StatsActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private TextView tvTotalHabits, tvTotalCompletions, tvBestStreak;
    private RecyclerView recyclerStats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Statistics");
        }

        db = DatabaseHelper.getInstance(this);

        tvTotalHabits = findViewById(R.id.tv_total_habits);
        tvTotalCompletions = findViewById(R.id.tv_total_completions);
        tvBestStreak = findViewById(R.id.tv_best_streak);
        recyclerStats = findViewById(R.id.recycler_stats);
        recyclerStats.setLayoutManager(new LinearLayoutManager(this));

        loadStats();
    }

    private void loadStats() {
        List<Habit> habits = db.getAllHabits();
        tvTotalHabits.setText(String.valueOf(habits.size()));

        int totalCompletions = 0;
        int bestStreak = 0;
        for (Habit h : habits) {
            totalCompletions += db.getTotalCompletions(h.getId());
            if (h.getStreak() > bestStreak) bestStreak = h.getStreak();
        }

        tvTotalCompletions.setText(String.valueOf(totalCompletions));
        tvBestStreak.setText(bestStreak + " days 🔥");

        // Sort by streak desc for leaderboard
        habits.sort((a, b) -> b.getStreak() - a.getStreak());

        HabitStatsAdapter adapter = new HabitStatsAdapter(this, habits, db);
        recyclerStats.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
