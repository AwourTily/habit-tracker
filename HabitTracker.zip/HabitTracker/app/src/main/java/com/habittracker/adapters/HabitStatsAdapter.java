package com.habittracker.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.habittracker.R;
import com.habittracker.database.DatabaseHelper;
import com.habittracker.models.Habit;

import java.util.List;

public class HabitStatsAdapter extends RecyclerView.Adapter<HabitStatsAdapter.StatsViewHolder> {

    private Context context;
    private List<Habit> habits;
    private DatabaseHelper db;

    public HabitStatsAdapter(Context context, List<Habit> habits, DatabaseHelper db) {
        this.context = context;
        this.habits = habits;
        this.db = db;
    }

    @NonNull
    @Override
    public StatsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_habit_stats, parent, false);
        return new StatsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StatsViewHolder holder, int position) {
        Habit habit = habits.get(position);
        holder.tvName.setText(habit.getName());
        holder.tvStreak.setText("🔥 " + habit.getStreak() + " day streak");
        holder.tvTotal.setText(db.getTotalCompletions(habit.getId()) + " completions");
        holder.tvRank.setText("#" + (position + 1));

        try {
            int color = Color.parseColor(habit.getColor());
            holder.tvName.setTextColor(color);
            holder.tvRank.setTextColor(color);
        } catch (Exception ignored) {}
    }

    @Override
    public int getItemCount() { return habits.size(); }

    static class StatsViewHolder extends RecyclerView.ViewHolder {
        TextView tvRank, tvName, tvStreak, tvTotal;
        StatsViewHolder(@NonNull View itemView) {
            super(itemView);
            tvRank = itemView.findViewById(R.id.tv_rank);
            tvName = itemView.findViewById(R.id.tv_stat_name);
            tvStreak = itemView.findViewById(R.id.tv_stat_streak);
            tvTotal = itemView.findViewById(R.id.tv_stat_total);
        }
    }
}
