package com.habittracker.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.habittracker.R;
import com.habittracker.models.Habit;

import java.util.List;

public class HabitAdapter extends RecyclerView.Adapter<HabitAdapter.HabitViewHolder> {

    public interface HabitClickListener {
        void onHabitCheck(Habit habit, boolean checked);
        void onHabitClick(Habit habit);
        void onHabitEdit(Habit habit);
    }

    private Context context;
    private List<Habit> habits;
    private HabitClickListener listener;

    public HabitAdapter(Context context, List<Habit> habits, HabitClickListener listener) {
        this.context = context;
        this.habits = habits;
        this.listener = listener;
    }

    public void updateHabits(List<Habit> newHabits) {
        this.habits = newHabits;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public HabitViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_habit, parent, false);
        return new HabitViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HabitViewHolder holder, int position) {
        Habit habit = habits.get(position);

        holder.tvName.setText(habit.getName());
        holder.tvStreak.setText("🔥 " + habit.getStreak());
        holder.tvFrequency.setText(habit.getFrequency().toUpperCase());

        // Color accent
        try {
            int color = Color.parseColor(habit.getColor());
            holder.colorBar.setBackgroundColor(color);
            holder.tvFrequency.setTextColor(color);
        } catch (Exception ignored) {}

        // Description
        if (habit.getDescription() != null && !habit.getDescription().isEmpty()) {
            holder.tvDesc.setVisibility(View.VISIBLE);
            holder.tvDesc.setText(habit.getDescription());
        } else {
            holder.tvDesc.setVisibility(View.GONE);
        }

        // Checkbox without triggering listener
        holder.checkBox.setOnCheckedChangeListener(null);
        holder.checkBox.setChecked(habit.isCompletedToday());
        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) ->
                listener.onHabitCheck(habit, isChecked));

        // Dim if completed
        holder.cardView.setAlpha(habit.isCompletedToday() ? 0.7f : 1.0f);

        holder.cardView.setOnClickListener(v -> listener.onHabitClick(habit));
        holder.btnEdit.setOnClickListener(v -> listener.onHabitEdit(habit));
    }

    @Override
    public int getItemCount() {
        return habits.size();
    }

    static class HabitViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        View colorBar;
        TextView tvName, tvDesc, tvStreak, tvFrequency;
        CheckBox checkBox;
        ImageButton btnEdit;

        HabitViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card_habit);
            colorBar = itemView.findViewById(R.id.view_color_bar);
            tvName = itemView.findViewById(R.id.tv_habit_name);
            tvDesc = itemView.findViewById(R.id.tv_habit_desc);
            tvStreak = itemView.findViewById(R.id.tv_streak);
            tvFrequency = itemView.findViewById(R.id.tv_frequency);
            checkBox = itemView.findViewById(R.id.checkbox_done);
            btnEdit = itemView.findViewById(R.id.btn_edit);
        }
    }
}
