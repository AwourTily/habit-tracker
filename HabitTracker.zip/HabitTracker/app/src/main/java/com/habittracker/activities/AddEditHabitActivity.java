package com.habittracker.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.habittracker.R;
import com.habittracker.database.DatabaseHelper;
import com.habittracker.models.Habit;

public class AddEditHabitActivity extends AppCompatActivity {

    private EditText etName, etDescription;
    private RadioGroup rgFrequency;
    private Spinner spinnerColor, spinnerIcon;
    private Button btnSave, btnDelete;
    private DatabaseHelper db;
    private int habitId = -1;
    private Habit existingHabit;

    private static final String[] COLORS = {"#4CAF50", "#2196F3", "#F44336", "#FF9800", "#9C27B0", "#00BCD4"};
    private static final String[] COLOR_NAMES = {"Green", "Blue", "Red", "Orange", "Purple", "Cyan"};
    private static final String[] ICONS = {"star", "fitness", "book", "water", "sleep", "meditation"};
    private static final String[] ICON_LABELS = {"⭐ Star", "💪 Fitness", "📚 Read", "💧 Water", "😴 Sleep", "🧘 Meditate"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_habit);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        db = DatabaseHelper.getInstance(this);

        etName = findViewById(R.id.et_name);
        etDescription = findViewById(R.id.et_description);
        rgFrequency = findViewById(R.id.rg_frequency);
        spinnerColor = findViewById(R.id.spinner_color);
        spinnerIcon = findViewById(R.id.spinner_icon);
        btnSave = findViewById(R.id.btn_save);
        btnDelete = findViewById(R.id.btn_delete);

        // Setup spinners
        ArrayAdapter<String> colorAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, COLOR_NAMES);
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerColor.setAdapter(colorAdapter);

        ArrayAdapter<String> iconAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ICON_LABELS);
        iconAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerIcon.setAdapter(iconAdapter);

        // Check if editing
        habitId = getIntent().getIntExtra("habit_id", -1);
        if (habitId != -1) {
            setTitle("Edit Habit");
            btnDelete.setVisibility(View.VISIBLE);
            existingHabit = db.getHabitById(habitId);
            populateFields(existingHabit);
        } else {
            setTitle("New Habit");
            btnDelete.setVisibility(View.GONE);
        }

        btnSave.setOnClickListener(v -> saveHabit());
        btnDelete.setOnClickListener(v -> deleteHabit());
    }

    private void populateFields(Habit habit) {
        etName.setText(habit.getName());
        etDescription.setText(habit.getDescription());

        if ("weekly".equals(habit.getFrequency())) {
            rgFrequency.check(R.id.rb_weekly);
        } else {
            rgFrequency.check(R.id.rb_daily);
        }

        // Set color spinner
        for (int i = 0; i < COLORS.length; i++) {
            if (COLORS[i].equals(habit.getColor())) {
                spinnerColor.setSelection(i);
                break;
            }
        }

        // Set icon spinner
        for (int i = 0; i < ICONS.length; i++) {
            if (ICONS[i].equals(habit.getIcon())) {
                spinnerIcon.setSelection(i);
                break;
            }
        }
    }

    private void saveHabit() {
        String name = etName.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            etName.setError("Please enter a habit name");
            etName.requestFocus();
            return;
        }

        String frequency = rgFrequency.getCheckedRadioButtonId() == R.id.rb_weekly ? "weekly" : "daily";
        String color = COLORS[spinnerColor.getSelectedItemPosition()];
        String icon = ICONS[spinnerIcon.getSelectedItemPosition()];

        if (habitId == -1) {
            // New habit
            Habit habit = new Habit(name, description, frequency, color, icon);
            long id = db.insertHabit(habit);
            if (id != -1) {
                Toast.makeText(this, "Habit created!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Error creating habit", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Update habit
            existingHabit.setName(name);
            existingHabit.setDescription(description);
            existingHabit.setFrequency(frequency);
            existingHabit.setColor(color);
            existingHabit.setIcon(icon);
            db.updateHabit(existingHabit);
            Toast.makeText(this, "Habit updated!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void deleteHabit() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Delete Habit")
                .setMessage("Are you sure you want to delete \"" + existingHabit.getName() + "\"? All history will be lost.")
                .setPositiveButton("Delete", (dialog, which) -> {
                    db.deleteHabit(habitId);
                    Toast.makeText(this, "Habit deleted", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
