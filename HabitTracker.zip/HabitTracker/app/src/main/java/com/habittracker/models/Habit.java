package com.habittracker.models;

public class Habit {
    private int id;
    private String name;
    private String description;
    private String frequency; // daily, weekly
    private String color;
    private String icon;
    private int streak;
    private long createdAt;
    private boolean completedToday;

    public Habit() {}

    public Habit(String name, String description, String frequency, String color, String icon) {
        this.name = name;
        this.description = description;
        this.frequency = frequency;
        this.color = color;
        this.icon = icon;
        this.streak = 0;
        this.createdAt = System.currentTimeMillis();
        this.completedToday = false;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getFrequency() { return frequency; }
    public void setFrequency(String frequency) { this.frequency = frequency; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public int getStreak() { return streak; }
    public void setStreak(int streak) { this.streak = streak; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    public boolean isCompletedToday() { return completedToday; }
    public void setCompletedToday(boolean completedToday) { this.completedToday = completedToday; }
}
