package com.habittracker.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.habittracker.R;
import com.habittracker.adapters.LogAdapter;
import com.habittracker.database.DatabaseHelper;
import com.habittracker.models.Habit;
import com.habittracker.models.HabitLog;

import java.util.List;

public class HabitDetailActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private Habit habit;
    private int habitId;

    private TextView tvHabitName, tvHabitDesc, tvStreak, tvTotal, tvFrequency, tvCompletedToday;
    private RecyclerView recyclerLogs;
    private Button btnToggle, btnEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_habit_detail);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Habit Details");
        }

        db = DatabaseHelper.getInstance(this);
        habitId = getIntent().getIntExtra("habit_id", -1);

        tvHabitName = findViewById(R.id.tv_habit_name);
        tvHabitDesc = findViewById(R.id.tv_habit_desc);
        tvStreak = findViewById(R.id.tv_streak);
        tvTotal = findViewById(R.id.tv_total);
        tvFrequency = findViewById(R.id.tv_frequency);
        tvCompletedToday = findViewById(R.id.tv_completed_today);
        recyclerLogs = findViewById(R.id.recycler_logs);
        btnToggle = findViewById(R.id.btn_toggle_today);
        btnEdit = findViewById(R.id.btn_edit);

        recyclerLogs.setLayoutManager(new LinearLayoutManager(this));

        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddEditHabitActivity.class);
            intent.putExtra("habit_id", habitId);
            startActivity(intent);
        });

        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        if (habitId == -1) { finish(); return; }

        habit = db.getHabitById(habitId);
        if (habit == null) { finish(); return; }

        tvHabitName.setText(habit.getName());
        tvHabitDesc.setText(habit.getDescription() != null && !habit.getDescription().isEmpty()
                ? habit.getDescription() : "No description");
        tvStreak.setText(habit.getStreak() + " day streak 🔥");
        tvTotal.setText(db.getTotalCompletions(habitId) + " total completions");
        tvFrequency.setText(capitalize(habit.getFrequency()));

        // Color accent
        try {
            int color = Color.parseColor(habit.getColor());
            tvHabitName.setTextColor(color);
            tvStreak.setTextColor(color);
        } catch (Exception ignored) {}

        if (habit.isCompletedToday()) {
            tvCompletedToday.setText("✅ Completed today!");
            tvCompletedToday.setTextColor(Color.parseColor("#4CAF50"));
            btnToggle.setText("Undo Today");
        } else {
            tvCompletedToday.setText("⬜ Not completed yet");
            tvCompletedToday.setTextColor(Color.parseColor("#9E9E9E"));
            btnToggle.setText("Mark Done Today");
        }

        btnToggle.setOnClickListener(v -> {
            if (habit.isCompletedToday()) {
                db.removeCompletion(habitId);
            } else {
                db.logCompletion(habitId, "");
            }
            loadData();
        });

        List<HabitLog> logs = db.getLogsForHabit(habitId);
        LogAdapter logAdapter = new LogAdapter(this, logs);
        recyclerLogs.setAdapter(logAdapter);
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
