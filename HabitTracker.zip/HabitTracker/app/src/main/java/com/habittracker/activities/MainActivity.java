package com.habittracker.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.habittracker.R;
import com.habittracker.adapters.HabitAdapter;
import com.habittracker.database.DatabaseHelper;
import com.habittracker.models.Habit;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements HabitAdapter.HabitClickListener {

    private RecyclerView recyclerView;
    private HabitAdapter adapter;
    private DatabaseHelper db;
    private TextView tvDate, tvProgress, tvEmpty;
    private List<Habit> habits;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = DatabaseHelper.getInstance(this);

        tvDate = findViewById(R.id.tv_date);
        tvProgress = findViewById(R.id.tv_progress);
        tvEmpty = findViewById(R.id.tv_empty);
        recyclerView = findViewById(R.id.recycler_habits);

        // Show today's date
        String today = new SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(new Date());
        tvDate.setText(today);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FloatingActionButton fab = findViewById(R.id.fab_add);
        fab.setOnClickListener(v -> {
            startActivity(new Intent(this, AddEditHabitActivity.class));
        });

        loadHabits();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHabits();
    }

    private void loadHabits() {
        habits = db.getAllHabits();

        if (habits.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
            tvProgress.setText("No habits yet");
        } else {
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);

            long completed = habits.stream().filter(Habit::isCompletedToday).count();
            tvProgress.setText(completed + " / " + habits.size() + " completed today");

            if (adapter == null) {
                adapter = new HabitAdapter(this, habits, this);
                recyclerView.setAdapter(adapter);
            } else {
                adapter.updateHabits(habits);
            }
        }
    }

    @Override
    public void onHabitCheck(Habit habit, boolean checked) {
        if (checked) {
            db.logCompletion(habit.getId(), "");
        } else {
            db.removeCompletion(habit.getId());
        }
        loadHabits();
    }

    @Override
    public void onHabitClick(Habit habit) {
        Intent intent = new Intent(this, HabitDetailActivity.class);
        intent.putExtra("habit_id", habit.getId());
        startActivity(intent);
    }

    @Override
    public void onHabitEdit(Habit habit) {
        Intent intent = new Intent(this, AddEditHabitActivity.class);
        intent.putExtra("habit_id", habit.getId());
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_stats) {
            startActivity(new Intent(this, StatsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
